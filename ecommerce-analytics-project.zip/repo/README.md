# E-Commerce Customer Analytics

A Python-based analysis of e-commerce transaction data covering customer segmentation, cohort retention, and revenue trends, built with pandas, seaborn, and matplotlib.

## Project Overview

This project analyzes transactional e-commerce data (`CustomerID`, `InvoiceDate`, `Quantity`, `UnitPrice`, `Country`) to answer core business questions:

- Who are our most valuable customers, and who is at risk of churning?
- How does revenue and active-customer count trend month over month?
- How well do we retain customers over time (cohort analysis)?
- What actions should the business take based on these patterns?

## Dataset

- **Source:** Mock dataset generated to resemble the [UCI Online Retail II dataset](https://archive.ics.uci.edu/dataset/502/online+retail+ii) (also available on Kaggle).
- **Location:** `data/mock_ecommerce_data.csv`
- **Fields:** `InvoiceNo`, `CustomerID`, `InvoiceDate`, `Description`, `Quantity`, `UnitPrice`, `Country`

To swap in the real Online Retail II dataset instead, download it from UCI or Kaggle and update the file path in the notebook's data-loading cell.

## Project Structure

```
├── data/
│   └── mock_ecommerce_data.csv       # Raw dataset
├── notebooks/
│   └── ecommerce_setup.ipynb         # Full analysis notebook
├── visuals/
│   └── (chart images exported from the notebook)
├── requirements.txt                  # Python dependencies
└── README.md
```

## Methodology

1. **Data Cleaning** — removed rows with negative/zero `Quantity` or `UnitPrice` (cancellations, test entries), dropped rows with missing `CustomerID`.
2. **Feature Engineering** — created `TotalSpend` (`Quantity × UnitPrice`), extracted `InvoiceMonth`, `InvoiceYear`, and `DayOfWeek`.
3. **RFM Analysis** — calculated Recency, Frequency, and Monetary value per customer.
4. **Cohort Analysis** — grouped customers by first-purchase month and tracked retention over subsequent months, visualized as a heatmap.
5. **KPI Calculation** — Total Revenue, Active Customers, Average Order Value (AOV), and 90-day Churn Rate.
6. **Customer Segmentation** — bucketed customers into High-Value Loyal, At-Risk, Churned, and Regular segments based on RFM values.
7. **Revenue vs. Risk Analysis** — compared revenue contribution against churn risk across segments.

## Key Visuals

- Revenue growth vs. Monthly Active Users (dual-axis line chart)
- Customer segment distribution (bar chart)
- Revenue contribution by segment (bar chart)
- Cohort retention heatmap

*(Exported chart images live in `visuals/`.)*

## Recommendations

Based on the analysis, three targeted actions emerged:

1. **Re-engagement campaign** for At-Risk customers (Recency 30–90 days) — the most cost-effective group to win back before full churn.
2. **Loyalty perks** for High-Value Loyal customers, given their disproportionate share of total revenue.
3. **Segmented win-back strategy** for Churned customers — split by purchase Frequency before re-engaging, since repeat buyers who went quiet differ from one-time buyers who were never engaged.

## How to Run

```bash
git clone <your-repo-url>
cd <repo-name>
pip install -r requirements.txt
jupyter notebook notebooks/ecommerce_setup.ipynb
```

Run all cells from top to bottom.

## Tools Used

Python, pandas, numpy, matplotlib, seaborn, sqlalchemy, Jupyter Notebook
